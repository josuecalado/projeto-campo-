let timeMode = "day"; // Alterna entre dia e noite
let raining = false; // Define se está chovendo
let clouds = [];
let car;

function setup() {
  createCanvas(600, 400);

  // Criando nuvens iniciais
  for (let i = 0; i < 4; i++) {
    clouds.push({ x: random(width), y: random(50, 150), speed: random(0.5, 1.5) });
  }

  // Criando carro
  car = { x: 0, y: 320, speed: 2 };
}

function draw() {
  // Céu variando com o tempo
  let skyColor = timeMode === "day" ? color(135, 206, 235) : color(40, 40, 80);
  background(skyColor);

  // Campo verde
  fill(34, 139, 34);
  rect(0, 280, width, height - 280);

  // Estrada
  fill(50);
  rect(0, 320, width, 40);

  // Casa
  fill(200, 100, 50);
  rect(400, 200, 100, 80); // Corpo
  fill(150, 75, 0);
  triangle(400, 200, 450, 150, 500, 200); // Telhado
  fill(255);
  rect(430, 230, 20, 30); // Janela
  rect(460, 240, 20, 40); // Porta

  // Árvores
  for (let x of [100, 200, 300]) {
    fill(139, 69, 19);
    rect(x, 260, 10, 30);
    fill(34, 139, 34);
    ellipse(x + 5, 240, 40, 40);
  }

  // Sol e Lua alternando
  let sunMoonColor = timeMode === "day" ? color(255, 255, 0) : color(200);
  let sunMoonX = width - 100;
  let sunMoonY = timeMode === "day" ? 100 : 50;
  fill(sunMoonColor);
  ellipse(sunMoonX, sunMoonY, 40, 40);

  // Nuvens se movendo
  fill(255);
  for (let cloud of clouds) {
    ellipse(cloud.x, cloud.y, 50, 30);
    ellipse(cloud.x + 20, cloud.y - 10, 40, 25);
    cloud.x += cloud.speed;
    if (cloud.x > width) cloud.x = -50; // Resetando posição
  }

  // Chuva se estiver ativada
  if (raining) {
    fill(0, 0, 255);
    for (let i = 0; i < 100; i++) {
      ellipse(random(width), random(height), 2, 10);
    }
  }

  // Movendo o carro
  fill(255, 0, 0);
  rect(car.x, car.y, 50, 25);
  fill(0);
  ellipse(car.x + 10, car.y + 25, 10, 10);
  ellipse(car.x + 40, car.y + 25, 10, 10);
  car.x += car.speed;
  if (car.x > width) car.x = -50;
}

function keyPressed() {
  if (keyCode === ENTER) {
    // Alternar entre dia e noite
    timeMode = timeMode === "day" ? "night" : "day";
  } else if (key === " ") {
    // Alternar chuva
    raining = !raining;
  }
}